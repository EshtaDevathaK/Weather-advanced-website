
// import './App.css'


import WeatherApp from "./WeatherApp.jsx";


function App() {

return (
    <>
     <WeatherApp/>
    </>

  );
}

export default App;
